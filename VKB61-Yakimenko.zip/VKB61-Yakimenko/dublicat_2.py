# Импорт необходимых библиотек/модулей
import numpy as np
import os
import sys
from PIL import Image, ImageQt
import keras
from PyQt5.QtCore import Qt, QPoint, QBuffer
from PyQt5.QtGui import QImage, QPainter, QPen, QFont, QOpenGLBuffer
from PyQt5.QtWidgets import QPushButton, QMainWindow, QLabel, QLineEdit, QApplication, QFileDialog
from tensorflow import keras

import passwd

# Установка переменной окружения QT_QPA_PLATFORM_PLUGIN_PATH для работы с плагином PyQt5
os.environ['QT_QPA_PLATFORM_PLUGIN_PATH'] = 'venv/Lib/site-packages/PyQt5/Qt5/plugins/'

class Window(QMainWindow):
    # Графический интерфейс
    def __init__(self):
        super().__init__()

        # Наименование и размерность окна
        title = "Распознавание буквы кириллицы"
        top = 200
        left = 200
        width = 540
        height = 350

        # Шрифты
        font = QFont('Arial', 10)
        fontBig = QFont('Arial', 12)

        # Кисть для рисования
        self.drawing = False
        self.brushSize = 8
        self.brushColor = Qt.black
        self.lastPoint = QPoint()

        # Холст
        self.image = QImage(278, 278, QImage.Format_RGB32)
        self.image.fill(Qt.white)

        # Лейбл "Логин"
        label = QLabel('ЛОГИН:', self)
        label.setFont(font)
        label.move(290, 30)

        # Размерность и расположение поля "Логин"
        self.line5 = QLineEdit(self)
        self.line5.setFont(fontBig)
        self.line5.move(400, 18)
        self.line5.resize(99, 42)

        # Лейбл "результат 1"
        label = QLabel('ДИРЕКТОРИЯ:', self)
        label.setFont(font)
        label.move(290, 140)

        # Размерность и расположение поля "результат 1"
        self.line = QLineEdit(self)
        self.line.setFont(fontBig)
        self.line.move(400, 134)
        self.line.resize(99, 42)

        # Лейбл "результат 2"
        label = QLabel('БУКВА:', self)
        label.setFont(font)
        label.move(290, 190)

        # Размерность и расположение поля "результат 2"
        self.line2 = QLineEdit(self)
        self.line2.setFont(fontBig)
        self.line2.move(400, 184)
        self.line2.resize(99, 42)

        # Лейбл "Кодовое слово"
        label = QLabel('КОДОВОЕ СЛОВО:', self)
        label.setFont(font)
        label.move(290, 230)

        # Размерность и расположение поля "Кодовое слово"
        self.line3 = QLineEdit(self)
        self.line3.setFont(fontBig)
        self.line3.move(400, 234)
        self.line3.resize(99, 42)

        # Размерность и расположение поля "Результат входа"
        self.line4 = QLineEdit(self)
        self.line4.setFont(fontBig)
        self.line4.move(20, 290)
        self.line4.resize(240, 35)

        # Кнопка "распознать"
        recognize_button = QPushButton('РАСПОЗНАТЬ', self)
        recognize_button.setFont(font)
        recognize_button.move(290, 65)
        recognize_button.resize(230, 33)
        recognize_button.clicked.connect(self.save)
        recognize_button.clicked.connect(self.prediction)
        recognize_button.clicked.connect(self.prediction2)

        # Кнопка "вход"
        recognize_button = QPushButton('ВХОД', self)
        recognize_button.setFont(font)
        recognize_button.move(290, 290)
        recognize_button.resize(230, 33)
        recognize_button.clicked.connect(self.vhod)

        # Кнопка "очистить"
        clean_button = QPushButton('ОЧИСТИТЬ', self)
        clean_button.setFont(font)
        clean_button.move(290, 100)
        clean_button.resize(230, 33)
        clean_button.clicked.connect(self.clear)
        clean_button.clicked.connect(self.line.clear)
        clean_button.clicked.connect(self.line2.clear)
        clean_button.clicked.connect(self.line3.clear)
        clean_button.clicked.connect(self.line4.clear)
        clean_button.clicked.connect(self.line5.clear)

        # Разрешаем принимать файлы на окно GUI
        self.setAcceptDrops(True)
        self.setWindowTitle(title)
        self.setGeometry(top, left, width, height)

    # Метод принимающий результат распознавания буквы и вывод ее на поле "результат"
    def vivod_letter(self, result1):
        spisok = "1432"
        self.line.setText(str(spisok[result1]))
        return spisok[result1]

    # Метод загрузки модели нейронной сети и изображения буквы
    def prediction(self):
        image = keras.preprocessing.image
        model = keras.models.load_model('/Users/alexey_yakimenko/PycharmProjects/NERO1/weight/model_workers.h5')
        img = image.load_img('res.jpg', target_size=(32,32))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        images = np.vstack([x])
        classes = model.predict(images, batch_size=1)

        # Получение результата
        result = int(np.argmax(classes))
        self.vivod_letter(result)



    def vivod_letter2(self, result2):
        letters = "БФЖУЪПЭИЬЫОЗТАХЁЙЕРВЧЮЛЩМШНЯКГЦДС"
        self.line2.setText(str(letters[result2]))
        return letters[result2]

    # Метод загрузки модели нейронной сети и изображения буквы
    def prediction2(self):
        image = keras.preprocessing.image
        model = keras.models.load_model('/Users/alexey_yakimenko/PycharmProjects/NERO1/weight/model_bukva.h5')
        img = image.load_img('res.jpg', target_size=(32,32))
        x = image.img_to_array(img)
        x = np.expand_dims(x, axis=0)
        images = np.vstack([x])
        classes = model.predict(images, batch_size=1)

        # Получение результата
        result = int(np.argmax(classes))
        self.vivod_letter2(result)


    #Метод проверки пользователя и его кодового слова
    def vhod(self):
        login = self.line5.text()
        if login in passwd.users1:
            directory = self.line.text()
            code_word = self.line3.text()
            if directory == passwd.users1[self.line5.text()]:
                if code_word == passwd.users2[self.line5.text()]:
                    self.line4.setText("Вход успешный!")
                else:
                    self.line4.setText("Неудачный вход...")
        else:
            self.line4.setText("Неверный Логин")

    # Методы mousePressEvent, mouseMoveEvent, mouseReleaseEvent, paintEvent
    # отображают реагирование на движение и нажатие кнопок мыши и отображение изменения на экране
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drawing = True
            self.lastPoint = event.pos()

    def mouseMoveEvent(self, event):
        if (event.buttons() & Qt.LeftButton) & self.drawing:
            painter = QPainter(self.image)
            painter.setPen(QPen(self.brushColor, self.brushSize, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
            painter.drawLine(self.lastPoint, event.pos())
            self.lastPoint = event.pos()
            self.update()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.drawing = False

    def paintEvent(self, event):
        canvas_painter = QPainter(self)
        canvas_painter.drawImage(0, 0, self.image)

    # Метод сохранения изображения буквы
    def save(self):
        self.image.save('res.jpg')

    # Метод очищения холста
    def clear(self):
        self.image = QImage(278, 278, QImage.Format_RGB32)
        self.image.fill(Qt.white)
        self.update()

    def dropEvent(self, event):
        for url in event.mimeData().urls():
            fname = url.toLocalFile()
            if fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                img = Image.open(fname)
                img = img.resize((278, 278), Image.BILINEAR)
                img.save(fname)
                self.image = QImage(fname)
                self.prediction()
                self.image = QImage(fname)
                self.prediction2()
                self.vhod()
                self.update()
                break


# Конструкция для запуска приложения с GUI
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Window()
    window.show()
    app.exec()