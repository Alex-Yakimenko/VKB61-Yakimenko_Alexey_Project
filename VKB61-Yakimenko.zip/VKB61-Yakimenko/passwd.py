users1 = {
    "qwerty" : "1",
    "slayer" : "2",
    "programmer" : "3",
    "veteran" : "4",
};
users2 = {
    "qwerty" : "Кордегон",
    "slayer" : "Слайзерак",
    "programmer" : "Экзастрайкер",
    "veteran" : "Мантибор",
}