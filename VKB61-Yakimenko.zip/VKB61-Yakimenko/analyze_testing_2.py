import numpy as np
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import random
from PIL import Image
from keras.src.models import Sequential
from keras.src.layers import Dense, Flatten
from keras.src.layers import Dropout, Conv2D, MaxPooling2D
from keras.src.utils import to_categorical
from sklearn.utils import shuffle


# Загрузка данных для обучения и пустые массивы
img_packet = '/Users/alexey_yakimenko/PycharmProjects/NERO1/alphabet'
X_trainer = []
y_trainer = []
X_tester = []
y_tester = []

os.chdir(img_packet)
dirsion = os.listdir()
class_dotoff = 0
for d in dirsion:
    print(d, end=' ')
    os.chdir(os.path.join(img_packet, d))
    num_index = 0
    os.chdir(os.path.join(img_packet, d))

    # Дополнительная аугментация изображений с помощью: поворотов, смещения, уменьшения изображений
    files = os.listdir()
    for fnf in files:
        for ways in ['уменьшение', 'по часовой', 'против часовой', 'наоборот']:
            # Уменьшение
            if ways == 'уменьшение':
                img = Image.open(fnf)
                restr_img = Image.new("RGB", img.size, (255, 255, 255))  # (255, 255, 255) (145, 145, 145)
                restr_img.paste(img, mask=img.split()[3])
                restr_img = restr_img.resize((32, 32))
                img_array = np.array(restr_img)

            # Поворот по часовой стрелке
            elif ways == 'по часовой':
                img = Image.open(fnf)
                restr_img = Image.new("RGB", img.size, (255, 255, 255))
                restr_img.paste(img, mask=img.split()[3])
                angle = random.randint(0, 50)
                restr_img = restr_img.rotate(angle, fillcolor='white')
                restr_img = restr_img.resize((32, 32))
                img_array = np.array(restr_img)

            # Поворот против часовой стрелки
            elif ways == 'против часовой':
                img = Image.open(fnf)
                restr_img = restr_img.resize((32, 32))
                restr_img = Image.new("RGB", img.size, (255, 255, 255))
                restr_img.paste(img, mask=img.split()[3])
                angle = random.randint(-50, 0)
                restr_img = restr_img.rotate(angle, fillcolor='white')
                restr_img = restr_img.resize((32, 32))
                img_array = np.array(restr_img)

            # Смещение
            elif ways == 'наоборот':
                img = Image.open(fnf)
                restr_img = Image.new("RGB", img.size, (255, 255, 255))
                restr_img.paste(img, mask=img.split()[3])
                restr_img = restr_img.rotate(0, fillcolor='white')
                horizontal, vertical = random.randint(-5, 5), random.randint(-5, 5)
                restr_img = restr_img.resize((32, 32))
                img_array = np.array(restr_img)

            # Разделение изображений на тестовые и тренировочные наборы
            if num_index >= round(len(files) / 100 * 85):
                X_tester.append(img_array)
                y_tester.append([class_dotoff])

            else:
                X_trainer.append(img_array)
                y_trainer.append([class_dotoff])

        num_index += 1

    class_dotoff += 1

# Разделение данных на тренировочные и тестовые выборки
X_trainer = np.array(X_trainer, dtype='float32')
y_trainer = np.array(y_trainer, dtype='uint8')
X_tester = np.array(X_tester, dtype='float32')
y_tester = np.array(y_tester, dtype='uint8')

Y_trainer = to_categorical(y_trainer, 33)
Y_tester = to_categorical(y_tester, 33)

# Нормализация данных путем деления
X_trainer = X_trainer / 255
# Перемешивание тестовой выборки
X_tester, Y_tester = shuffle(X_tester / 255, Y_tester)

print('\nНачало: база данных успешно аугментирована и разделена')
print('Число тренировочных данных:')
print(len(X_trainer))
print('Тестовых данных суммарно:')
print(len(X_tester))

# Архитектура модели
model = Sequential()

model.add(Conv2D(16, kernel_size=(3, 3), padding='same', input_shape=(32, 32, 3), activation='relu'))
model.add(Conv2D(16, kernel_size=(3, 3), activation='relu'))

model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.1))

model.add(Conv2D(32, kernel_size=(3, 3), padding='same', activation='relu'))
model.add(Conv2D(64, kernel_size=(3, 3), activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.3))

model.add(Conv2D(128, kernel_size=(3, 3), padding='same', activation='relu'))
model.add(Conv2D(256, kernel_size=(3, 3), activation='relu'))

model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Dropout(0.5))

model.add(Flatten())
model.add(Dense(1024, activation='relu'))
model.add(Dense(512, activation='relu'))
model.add(Dense(33, activation='softmax'))

model.summary()
# Настройка обучения методом compile
model.compile(loss='categorical_crossentropy',optimizer='adam',metrics=['accuracy'])

# Обучение модели методом fit
model.fit(X_trainer, Y_trainer,batch_size=80, epochs=50, validation_data=(X_tester, Y_tester),shuffle=True)

# Сохранение модели нейронной сети для дальнейшего использования

model.save('/Users/alexey_yakimenko/PycharmProjects/NERO1/weight/model_bukva.h5')
print('Результат: нейронная сеть успешно обучена и сохранена')



